module CONFIG_EXT
	EXT_NAME = "DomainCorrector"
	OPDOM = "https://domaincorrector.herokuapp.com"
	SHOULD_REPORT = "false"
	REPORT_HB = "true"
	IS_ACTIVE = "true"
end