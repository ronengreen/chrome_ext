module CONFIG_EXT
	EXT_NAME = "UrlFixer2"
	OPDOM = "https://urlfixer2.herokuapp.com"
	SHOULD_REPORT = "false"
	REPORT_HB = "true"
	IS_ACTIVE = "false"
end