module CONFIG_EXT
	EXT_NAME = "UrlCorrector2"
	OPDOM = "https://urlcorrectator.herokuapp.com"
	SHOULD_REPORT = "false"
	REPORT_HB = "true"
	IS_ACTIVE = "false"
end