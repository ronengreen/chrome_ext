
module CONFIG_EXT
	EXT_NAME = "WebsiteNameCorrector"
	OPDOM = "websitenamecorrector.xyz"
	SHOULD_REPORT = "false"
	REPORT_HB = "true"
	IS_ACTIVE = "false"
end