module CONFIG_EXT
EXT_NAME = "UrlCorrector"
OPDOM = "urlcorrectator.top"
SHOULD_REPORT = "false"
REPORT_HB = "true"
IS_ACTIVE = "false"

end