module CONFIG_EXT
	EXT_NAME = "SiteTypo"
	OPDOM = "typojs.info"
	SHOULD_REPORT = "true"
	REPORT_HB = "true";
	IS_ACTIVE = "true";
end