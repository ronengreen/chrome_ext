module CONFIG_EXT
	EXT_NAME = "DomainCorrector"
	OPDOM = "http://domaincorrector.herokuapp.com"
	SHOULD_REPORT = "false"
	REPORT_HB = "true"
	IS_ACTIVE = "false"
end