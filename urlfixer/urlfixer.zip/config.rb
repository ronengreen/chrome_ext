module CONFIG_EXT
EXT_NAME = "URlFixer"
OPDOM = "urlfixer.info"
SHOULD_REPORT = "false"
REPORT_HB = "true"
IS_ACTIVE = "false"
end