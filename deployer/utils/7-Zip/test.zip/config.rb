module CONFIG_EXT
	EXT_NAME = "dev_version_heroku"
	OPDOM = "http://localhost:3000"
	SHOULD_REPORT = "true"
	REPORT_HB = "true"
	IS_ACTIVE = "true"
end